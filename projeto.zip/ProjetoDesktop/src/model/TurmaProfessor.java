package model;

public class TurmaProfessor {
    private int intTurmaProfId, intTurmaId, intProfId;
    
    public TurmaProfessor(){
        
    }

    public int getIntTurmaProfId() {
        return intTurmaProfId;
    }

    public void setIntTurmaProfId(int intTurmaProfId) {
        this.intTurmaProfId = intTurmaProfId;
    }

    public int getIntTurmaId() {
        return intTurmaId;
    }

    public void setIntTurmaId(int intTurmaId) {
        this.intTurmaId = intTurmaId;
    }

    public int getIntProfId() {
        return intProfId;
    }

    public void setIntProfId(int intProfId) {
        this.intProfId = intProfId;
    }
    
}
