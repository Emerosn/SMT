package model;

public interface autenticar {
    boolean autenticar(String usr, String passwd);
}
