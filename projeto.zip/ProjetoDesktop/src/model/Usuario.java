package model;

public class Usuario {
    private String strUserName, strSenha, strUsuarioTipo;
    private int intUsuarioId;

    public String getStrUserName() {
        return strUserName;
    }

    public void setStrUserName(String strUserName) {
        this.strUserName = strUserName;
    }

    public String getStrSenha() {
        return strSenha;
    }

    public void setStrSenha(String strSenha) {
        this.strSenha = strSenha;
    }

    public String getStrUsuarioTipo() {
        return strUsuarioTipo;
    }

    public void setStrUsuarioTipo(String strUsuarioTipo) {
        this.strUsuarioTipo = strUsuarioTipo;
    }

    public int getIntUsuarioId() {
        return intUsuarioId;
    }

    public void setIntUsuarioId(int intUsuarioId) {
        this.intUsuarioId = intUsuarioId;
    }
    
    
}
