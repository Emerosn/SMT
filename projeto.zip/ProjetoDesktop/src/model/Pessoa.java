package model;

public class Pessoa {
    
    private int intPessoaId;
    private String strNomePessoa, strRgPessoa, strCpfPessoa, strTelPessoa, strEmailPessoa, strSexoPessoa, strCidadePessoa, strEnderecoPessoa, strUfPessoa;

    public String getStrUfPessoa() {
        return strUfPessoa;
    }

    public void setStrUfPessoa(String strUfPessoa) {
        this.strUfPessoa = strUfPessoa;
    }
    
    public String getStrCidadePessoa() {
        return strCidadePessoa;
    }

    public void setStrCidadePessoa(String strCidadePessoa) {
        this.strCidadePessoa = strCidadePessoa;
    }

    public String getStrEnderecoPessoa() {
        return strEnderecoPessoa;
    }

    public void setStrEnderecoPessoa(String strEnderecoPessoa) {
        this.strEnderecoPessoa = strEnderecoPessoa;
    }
    
    public int getIntPessoaId() {
        return intPessoaId;
    }

    public void setIntPessoaId(int intPessoaId) {
        this.intPessoaId = intPessoaId;
    }

    public String getStrNomePessoa() {
        return strNomePessoa;
    }

    public void setStrNomePessoa(String strNomePessoa) {
        this.strNomePessoa = strNomePessoa;
    }

    public String getStrRgPessoa() {
        return strRgPessoa;
    }

    public void setStrRgPessoa(String strRgPessoa) {
        this.strRgPessoa = strRgPessoa;
    }

    public String getStrCpfPessoa() {
        return strCpfPessoa;
    }

    public void setStrCpfPessoa(String strCpfPessoa) {
        this.strCpfPessoa = strCpfPessoa;
    }

    public String getStrTelPessoa() {
        return strTelPessoa;
    }

    public void setStrTelPessoa(String strTelPessoa) {
        this.strTelPessoa = strTelPessoa;
    }

    public String getStrEmailPessoa() {
        return strEmailPessoa;
    }

    public void setStrEmailPessoa(String strEmailPessoa) {
        this.strEmailPessoa = strEmailPessoa;
    }

    public String getStrSexoPessoa() {
        return strSexoPessoa;
    }

    public void setStrSexoPessoa(String strSexoPessoa) {
        this.strSexoPessoa = strSexoPessoa;
    }
    
    
    public Pessoa(){
        
    }
}
